#!/usr/bin/env bash
docker rm -f jupyter-tabnine-server
